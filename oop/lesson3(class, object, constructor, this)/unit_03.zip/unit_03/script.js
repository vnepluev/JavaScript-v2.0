const addButton = new Button('100px', '50px', 'green', 'кнопка')

document.querySelector('body').appendChild(addButton.render())

const modern = new ModernButton('100px', '50px', 'green', 'кнопка', '10px')

document.querySelector('body').appendChild(modern.render())


